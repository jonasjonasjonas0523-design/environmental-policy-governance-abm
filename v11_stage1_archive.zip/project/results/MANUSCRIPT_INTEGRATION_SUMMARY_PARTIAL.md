# MANUSCRIPT_INTEGRATION_SUMMARY (PARTIAL: stages through the principal reference plane)
Model v1.1-prerun-amended; see AMENDMENTS_PRE_RUN.md.

ABSTRACT: verification 24/24 PASS; held-out validation 4 of 5 satisfied (V5 fatal; voluntary external interpretation withdrawn); no statistically supported crossover on the reference plane within G_anchor (H3 SUPPORTED).

VI-A: V1 PASS, V2 PASS, V3 PASS, V4 PASS, V5 FAIL (all three parts; predicted analytically pre-run), V6 not retained.

VI-B: grid 41x41, n=153, k=0.30, h=0.75. Anchored fraction of the plane 0.29; unresolved fraction within G_anchor 0.00. Abatement leader: T (charge) on 1.00 of anchored cells, S on 0.00, not resolved on 0.00. Cost leader: V on 1.00 of anchored cells (the inert instrument spends nothing; descriptive only given V5). No cell shows joint Pareto dominance of any instrument (V's zero cost blocks it by construction at the frozen baseline).

VI-C: supported crossovers: see crossover_summary.csv.

H1 (interaction, DoD max-t over anchor cells): {'S-T|A': True, 'S-T|C_social': True, 'S-V|A': True, 'S-V|C_social': True, 'T-V|A': True, 'T-V|C_social': True}
H2 (surfaces differ over anchor): {'S-T': True, 'S-V': True, 'T-V': True}

PENDING (not run this stage): secondary k/h slices (VI-D), archetype probabilistic readouts (VI-E), Sobol sensitivity, mechanism ablations (VII-B), robustness families (VIII), full 4D G_anchor evaluation of H2/H3.
