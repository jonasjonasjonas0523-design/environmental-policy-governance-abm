# Held-out validation report (V1-V5; V6 not retained)
Model v1.1-prerun-amended; validation seeds 90000..90152 (n=153, disjoint from pilot and principal); criteria locked 2026-08-20.

| ID   | criterion                                        | result                                                                                              | status       | classification                                                         |
|:-----|:-------------------------------------------------|:----------------------------------------------------------------------------------------------------|:-------------|:-----------------------------------------------------------------------|
| V1   | band(dA)>0 AND band(dviol)<0                     | dA=57.9 [56.6,59.2]; dviol=-0.164 [-0.169,-0.159]                                                   | PASS         |                                                                        |
| V2   | effect in [10,40] pct per inspection; Z reported | 10.0 pct [9.9,10.2]; Z pending AUTHOR ACTION (empirical coeff+SE from ref [35] tables); sim SE=0.09 | PASS         |                                                                        |
| V3   | band(A_eng-A_dis)>0; A_dis<0.25 A*_cum           | diff=80.2 [79.3,81.2]; A_dis=21.9 (<100: True)                                                      | PASS         |                                                                        |
| V4   | A>=0.80 A*_cum AND under-reporting<5 pct         | A=358.4 [354.8,362.1] (>=320); under=0.00 pct                                                       | PASS         |                                                                        |
| V5   | bands>0 on: A_V(A1); A1-A4; A1-ablated           | A_V(A1)=0.00 [0.00,0.00]; A1-A4=0.00; abl diff=0.00                                                 | FAIL         | FATAL: voluntary external claims + shadow-of-regulation interpretation |
| V6   | not retained (pre-run decision 2026-08-20)       | no defensible single-setting anchor                                                                 | Not retained |                                                                        |

## Failure bookkeeping (VALIDATION_MEMO / PRE_REG Sec 9)
V5 FAILED in all three parts, as derived analytically pre-run in MISSING_OR_CONFLICTING_INPUTS.md v2 (the voluntary instrument is inert at the frozen nu, theta_0, lambda; amendment A1 makes the channel structurally capable, but the baseline numerics remain as frozen by author instruction). Scope per the predeclared rules: the FATAL classification voids the voluntary instrument's EXTERNAL claims and the shadow-of-regulation interpretation. The phase maps are reported with that external interpretation withdrawn; descriptive (model-internal) voluntary results stand, labelled accordingly. The protocol explicitly provides for continuation with the named instrument's interpretation withdrawn.

Outcome for the manuscript abstract: 4 of 5 predeclared held-out tests satisfied.
