# RESULTS_MANIFEST (stage: through principal reference plane)

PRODUCED:
- results/verification/verification_results.csv
- results/verification/verification_report.md
- results/verification/tau_star.json
- results/pilot/grid_resolution_results.csv
- results/pilot/grid_resolution_choice.json
- results/pilot/replication_pilot.csv
- results/pilot/replication_choice.json
- results/validation/validation_results.csv
- results/validation/validation_report.md
- results/principal/principal_raw_results.parquet
- results/principal/simultaneous_bands.parquet
- results/principal/max_t_summary.json
- results/principal/crossover_summary.csv
- results/principal/H_verdicts.json
- results/principal/principal_summary.csv
- results/MANUSCRIPT_INTEGRATION_SUMMARY_PARTIAL.md
- figures/Figure2.pdf/.png, Figure3.pdf/.png, Figure4.pdf/.png
- config/baseline.yaml; src/*.py; AMENDMENTS_PRE_RUN.md

PENDING:
- secondary k/h slice planes; 4D Saltelli/Sobol design; archetype readouts (probabilistic); ablations m1-m5; robustness families F1-F4; FINAL_COMPUTATIONAL_AUDIT.md (end of all stages)
