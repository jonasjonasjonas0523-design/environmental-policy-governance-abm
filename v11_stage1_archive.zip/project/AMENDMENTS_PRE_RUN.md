# AMENDMENTS_PRE_RUN.md
Model version: v1.1-prerun-amended. Refrozen 2026-08-20, before any validation or
principal run. Authorization: author instruction to proceed on the frozen package
and "correct the objectively wrong ones." No scientific parameter value was
changed and nothing was tuned toward any result. Baseline numerics are exactly
as frozen in CODE_INPUT_SPECIFICATION.md.

## A1. Voluntary participation carries the theta differential (structural correction)
As literally written, eq. (13) places the identical expected future-regime term
delta*h*theta_t*M_i in every option of the participation comparison, so theta
cancels and the threat channel is decision-irrelevant. That contradicts four
frozen package elements: the abstract and Section II-C (the voluntary channel
"implements the shadow-of-regulation mechanism"), the theoretical source ref
[14], validation test V5(iii) (the theta ablation must reduce voluntary
abatement, which is impossible for any parameters if theta cancels), and
ablation m4. Under the protocol's conflicting-documents rule, the equation is
the objectively wrong element and is corrected to carry the differential the
rest of the package presupposes.

Correction implemented (verification-gated exemption): a participant whose
achievement is verified in period t (probability p, the same monitoring
environment used everywhere else) is exempt from the threatened future regime.
The participation comparison becomes
    participate-and-achieve  iff  C_i(target) <= p * ( rho_i + delta*h*theta_t*M_i(g) ).
The verification gate follows the model's own principle that a voluntary claim
is only as strong as the verification regime behind it, and mirrors the
reputational payment, which also passes through p. Alternative considered and
not chosen: exemption deterministic on achievement regardless of verification,
    C_i(target)*(1 - p*nu) <= delta*h*theta_t*M_i(g),
which grants an unverified private benefit and sits worse with the equal-
services principle. At the frozen baseline numerics the two variants produce
identical behavior (no participation either way; see below), so the choice has
no effect on any baseline result. It matters only for robustness families F2
and the ablations, where the channel comes alive at higher nu or lambda. The
author can swap variants post hoc without touching any baseline output.

Consequence at baseline, stated in advance and confirmed by the run: with
nu = 0.25, theta_0 = -2.2, lambda = 3.0 frozen, the participation condition is
infeasible for every firm at every g in [0,1]^4 (upper bound p*(0.25 + 0.95*
0.690) = 0.905*p < 1 with M_i <= C_i). The instrument remains inert, V5 fails
in all three parts, and the failure is recorded as FATAL with the predeclared
scope: the voluntary instrument's external claims and the shadow-of-regulation
interpretation are withdrawn; phase maps report V descriptively. These
parameter values are calibration choices, not errors, and were left untouched
by author instruction. Revising them is a post-run model-revision decision.

## A2. Verification item 12 anchor restated (criterion correction)
The frozen anchor said the calibrated tau* sits "slightly above" 0.2/e = 0.0736.
The uncapped identity tau = A_bar/E[1/gamma] ignores the min(tau/gamma, E0) cap,
and the cap correction at the frozen distributions is large, not slight. A
correct solver would have failed the anchor as written. Restated criterion:
(i) the bisection converges to |F| < 1e-6 on the frozen quadrature sample
(1e6 draws, seed 424242); (ii) the solved tau* satisfies |F| < 5*SE on an
independent 1e6-draw sample; (iii) 0.2/e is a floor only. Measured: tau* =
0.093267, cap correction +26.8 percent over 0.2/e, independent-sample check
passed. Recorded in results/verification/tau_star.json.

## Interpretation pin-downs (defaults documented, not judgment calls)
P1. A* roles: the shortfall s_t uses the per-seed ambition A* = 0.2 * sum(E0_i)
    per period; fixed thresholds (A_min, epsilon_A, validation cutoffs such as
    320 and 100) use the nominal A*_cum = 400.
P2. Timing: firms act on the published theta_t formed from s_{t-1};
    theta_1 = logistic(theta_0).
P3. Violation rate = share of firm-periods with E > Ebar.
P4. Under-reporting share = sum(u) / sum(E), aggregate.
P5. kappa_I counts implemented consequences (standard penalties, charge evasion
    recoveries). Routine collection of the assessed charge is administration
    (kappa_A, one assessment per firm-period), not an implemented consequence.

## Execution-level operationalizations (logged for reproducibility)
- Seed protocol: pilot 1..10^4 (grid pilot 1..200; replication pilot
  1001..1200; battery test seeds 5001..5501 and 6001..6100), validation block
  90000..90152, principal 100000..100152. All disjoint.
- Grid pilot boundary metric: boundaries are supported-sign transitions
  (mean beyond 2*SE on both sides) of the Delta_ST surfaces on 41 reference
  lines per axis; nearest-matched max displacement; ladder 6, 11, 21, 41 with
  tolerance half the finer spacing and two-step stability. No step formally
  met its tolerance (shifts 0.054, 0.049, 0.024 against 0.05, 0.025, 0.0125),
  so the finest candidate, 41, was adopted and the non-convergence is logged in
  grid_resolution_choice.json (fallback_to_finest = true).
- Replication pilot: epsilon_C = 0.177 (0.05 x pilot mean C_social across the
  three instruments at reference), s_max_A = 24.51, s_max_C = 1.117, so
  n = max(6, 153) = 153, frozen.
- V2 rescaling: the p = 0.50 to 0.90 contrast on firms noncompliant at p = 0.50
  is divided by 0.4 to express the effect per one additional inspection per
  period. The empirical Z comparison remains AUTHOR ACTION (coefficient and SE
  from ref [35] tables); the locked pass criterion is the [10, 40] percent band.
- Test-harness note: the first run of verification item 13 (bitwise seed
  replication) reported FAIL because CE is legitimately NaN below A_min and
  NaN != NaN under the default comparator. The comparator was corrected to
  equal_nan=True and the battery rerun. This was a harness artifact, not a
  model defect; the original failing row is preserved in the shell log.
